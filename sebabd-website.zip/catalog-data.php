<?php
/**
 * SebaBD — catalog data layer.
 *
 * Storefront presentation data (images, marketing copy, deal badges) is NOT
 * part of the DBMS schema, so it lives here keyed by ProductID. The database
 * remains the single source of truth for products, categories, stock and
 * prices; this file only decorates what the database returns. Images come
 * from the official sebabd.com catalog.
 *
 * If MySQL is unreachable, these arrays double as a demo fallback so the
 * storefront still renders.
 */

/**
 * Image URL, deal badge and short blurb for each product, keyed by ProductID.
 */
function product_meta(): array
{
    $img = 'https://sebabd.com/wp-content/uploads/';

    return [
        1 => [
            'image' => $img . '2022/02/optiplex-24-7480-500x500-1-300x300.jpg',
            'alt'   => 'Dell Optiplex 24 7480 all-in-one PC',
            'badge' => 'Hot',
            'blurb' => 'Core i5-10500, 8 GB DDR4, 1 TB HDD with a 23.8" FHD IPS display — a complete office workstation in one.',
            'sale'  => 92800.00,
        ],
        2 => [
            'image' => $img . '2022/02/optiplex-22-3280-core-i5-500x500-1-300x300.jpg',
            'alt'   => 'Dell Optiplex 3280 all-in-one PC',
            'badge' => null,
            'blurb' => 'Core i3-10100T, 4 GB RAM, 1 TB HDD and a 21.5" FHD IPS display — space-saving front-desk machine.',
            'sale'  => 52500.00,
        ],
        3 => [
            'image' => $img . '2022/02/i7-10700k-0001-500x500-1-300x300.jpg',
            'alt'   => 'Star PC gaming desktop with Core i7 10700K',
            'badge' => 'Hot',
            'blurb' => 'Core i7-10700K with MSI MAG B560M Mortar WiFi, 8 GB DDR4 and a 256 GB SSD — built for gaming.',
            'sale'  => 82000.00,
        ],
        4 => [
            'image' => $img . '2022/02/star-pc-10th-gen-i7-10700-001-500x500-1-300x300.jpg',
            'alt'   => 'Star PC desktop with Core i7 10700',
            'badge' => null,
            'blurb' => 'Core i7-10700, MSI B560M-A Pro, 8 GB DDR4 3200 MHz and a 256 GB M.2 PCIe SSD for heavy workloads.',
            'sale'  => 53500.00,
        ],
        5 => [
            'image' => $img . '2022/02/star-pc-10th-gen-i5-10500-500x500-1-300x300.png',
            'alt'   => 'Star PC desktop with Core i5 10500',
            'badge' => 'Hot',
            'blurb' => 'Core i5-10500 desktop — the balanced pick for office workstations and everyday productivity.',
            'sale'  => 39000.00,
        ],
        6 => [
            'image' => $img . '2022/02/i3-10100-500x500-1-300x300.jpg',
            'alt'   => 'Star PC desktop with Core i3 10100',
            'badge' => 'Deal',
            'blurb' => 'Core i3-10100 desktop with fast SSD storage — an affordable starter PC for home and office.',
            'sale'  => 28000.00,
        ],
        7 => [
            'image' => $img . '2022/02/280-pro-g6-mt-001-500x500-1-300x300.png',
            'alt'   => 'HP 280 Pro G6 Microtower PC',
            'badge' => null,
            'blurb' => 'Core i3-10100 microtower bundled with an 18.5" HP monitor, keyboard and mouse — office ready.',
            'sale'  => 48500.00,
        ],
        8 => [
            'image' => $img . '2022/02/240-g8-0003-500x500-1-300x300.jpg',
            'alt'   => 'HP 240 G8 laptop',
            'badge' => 'New',
            'blurb' => 'Core i3-1115G4, 8 GB DDR4, 1 TB HDD and a 14" FHD display — thin, light and office-friendly.',
            'sale'  => 57000.00,
        ],
        9 => [
            'image' => $img . '2022/05/ip-slim-15-500x500-4-300x300.jpg',
            'alt'   => 'Asus VivoBook 14 X415FA laptop',
            'badge' => 'Hot',
            'blurb' => 'Core i3-10110U, 4 GB DDR4, 1 TB HDD in a 14" FHD chassis with a fingerprint sensor.',
            'sale'  => 47500.00,
        ],
        10 => [
            'image' => $img . '2022/05/ip-slim-15-500x500-1-300x300.jpg',
            'alt'   => 'Lenovo IdeaPad Slim 3i laptop',
            'badge' => null,
            'blurb' => 'Core i3-1005G1, 4 GB RAM, 1 TB HDD and Windows 11 on a 15.6" display — everyday value.',
            'sale'  => 45800.00,
        ],
        11 => [
            'image' => $img . '2022/05/vostro-15-3500-500x500-1-300x300.jpg',
            'alt'   => 'Dell Vostro 15 3500 laptop',
            'badge' => 'New',
            'blurb' => 'Core i3-1115G4, 4 GB DDR4 3200 MHz and a 15.6" FHD screen — small-business workhorse.',
            'sale'  => 47500.00,
        ],
        12 => [
            'image' => $img . '2023/02/m22f-1-300x300.jpg',
            'alt'   => 'HP M22f 22-inch FHD IPS monitor',
            'badge' => 'Hot',
            'blurb' => '22" FHD IPS, 75 Hz, HDMI + VGA with FreeSync and low-blue-light comfort.',
            'sale'  => 16800.00,
        ],
        13 => [
            'image' => $img . '2023/02/rmmnt215nf-01-500x500-1-300x300.jpg',
            'alt'   => 'Xiaomi Redmi 21.45-inch FHD monitor',
            'badge' => 'Deal',
            'blurb' => '21.45" FHD VA panel at 75 Hz with HDMI and VGA — big value for home and office desks.',
            'sale'  => 9900.00,
        ],
        14 => [
            'image' => $img . '2023/02/giant_205697-300x300.jpg',
            'alt'   => 'Value-Top T22VF 21.5-inch FHD monitor',
            'badge' => null,
            'blurb' => '21.5" FHD LED with a 75 Hz VA panel, slim bezels and low blue light.',
            'sale'  => 9900.00,
        ],
        15 => [
            'image' => $img . '2022/02/d1918h-01-500x500-1-300x300.jpg',
            'alt'   => 'Dell D1918H 18.5-inch LED monitor',
            'badge' => null,
            'blurb' => '18.5" LED with both VGA and HDMI inputs — a dependable budget display.',
            'sale'  => 9900.00,
        ],
        16 => [
            'image' => $img . '2022/02/107w-01-500x500-1-300x300.jpg',
            'alt'   => 'HP 107a laser printer',
            'badge' => 'Deal',
            'blurb' => 'Compact single-function laser — up to 20 ppm, 1200 x 1200 dpi, Hi-Speed USB 2.0.',
            'sale'  => 12000.00,
        ],
        17 => [
            'image' => $img . '2022/02/2523a-500x500-1-300x300.png',
            'alt'   => 'Toshiba e-Studio 2523A photocopier',
            'badge' => null,
            'blurb' => 'A3 multifunction digital photocopier — print, copy and scan for busy offices.',
            'sale'  => 46000.00,
        ],
        18 => [
            'image' => $img . '2022/02/eb-w06-500x500-1-300x300.jpg',
            'alt'   => 'Epson EB-W06 office projector',
            'badge' => 'Hot',
            'blurb' => '3700 lumens WXGA 3LCD with 12,000-hour lamp life in eco mode — bright meeting-room output.',
            'sale'  => 62000.00,
        ],
        19 => [
            'image' => $img . '2022/02/prolink-UPS-2.jpg',
            'alt'   => 'Prolink 650VA offline UPS',
            'badge' => null,
            'blurb' => '650 VA offline backup to keep your PC and router alive through load-shedding.',
            'sale'  => 2800.00,
        ],
        20 => [
            'image' => $img . '2022/02/havit-31026-01-600by600.jpg',
            'alt'   => 'Havit MS1026 gaming mouse',
            'badge' => 'Hot',
            'blurb' => '7-button gaming mouse with RGB backlight and adjustable DPI.',
            'sale'  => 650.00,
        ],
        21 => [
            'image' => $img . '2022/02/a4tech-2-300x300.jpg',
            'alt'   => 'A4Tech FG10 wireless mouse',
            'badge' => null,
            'blurb' => 'Wireless optical mouse with 2000 DPI and a comfortable ambidextrous shape.',
            'sale'  => 700.00,
        ],
        22 => [
            'image' => $img . '2022/02/a4tech-300x300.jpg',
            'alt'   => 'A4Tech OP-620D optical mouse',
            'badge' => null,
            'blurb' => 'Classic wired optical mouse with 2X click switches — the office staple.',
            'sale'  => 399.00,
        ],
        23 => [
            'image' => $img . '2022/02/logitech-mouse-300x300.png',
            'alt'   => 'Logitech M90 USB mouse',
            'badge' => null,
            'blurb' => 'Wired USB mouse with a contoured shape and smooth optical tracking.',
            'sale'  => 450.00,
        ],
        24 => [
            'image' => $img . '2022/02/e25a81d9d16813abccfdc1a3e665fd2c-300x300.png',
            'alt'   => 'Micropack M101 optical USB mouse',
            'badge' => 'Deal',
            'blurb' => 'Compact wired optical mouse — plug-and-play simplicity on a budget.',
            'sale'  => 300.00,
        ],
        25 => [
            'image' => $img . '2022/02/SSDKS128-2-300x300.jpg',
            'alt'   => 'Kingspec 128GB SATA SSD',
            'badge' => null,
            'blurb' => '128 GB 2.5" SATA III SSD — instantly revive an older desktop or laptop.',
            'sale'  => 2900.00,
        ],
        26 => [
            'image' => $img . '2023/02/product-facedeep3-300x300.png',
            'alt'   => 'Anviz FaceDeep 3 access control terminal',
            'badge' => 'New',
            'blurb' => 'Face + RFID cloud terminal: 6,000 users, 100,000 logs, dual camera, 5" touch screen.',
            'sale'  => 25000.00,
        ],
        27 => [
            'image' => $img . '2023/02/W2白色-正面-e1677396518402-300x300.png',
            'alt'   => 'Anviz W2 Pro access control terminal',
            'badge' => null,
            'blurb' => 'Fingerprint + RFID cloud terminal with WiFi, 10-hour backup and 3,000 fingerprint capacity.',
            'sale'  => 13000.00,
        ],
        28 => [
            'image' => $img . '2023/02/Anviz-W1-Pro-1-300x300.webp',
            'alt'   => 'Anviz W1 Pro access control terminal',
            'badge' => null,
            'blurb' => 'Compact fingerprint + RFID cloud terminal for attendance and door access.',
            'sale'  => 12000.00,
        ],
    ];
}

/**
 * Font Awesome icon per category name (used when a category has no icon mapping).
 */
function category_icon(string $name): string
{
    $map = [
        'Laptop'         => 'fa-solid fa-laptop',
        'Desktop PC'     => 'fa-solid fa-desktop',
        'All In One PC'  => 'fa-solid fa-display',
        'Monitor'        => 'fa-solid fa-tv',
        'Printer'        => 'fa-solid fa-print',
        'Photocopier'    => 'fa-solid fa-copy',
        'Projector'      => 'fa-solid fa-video',
        'UPS'            => 'fa-solid fa-car-battery',
        'Mouse'          => 'fa-solid fa-computer-mouse',
        'Storage'        => 'fa-solid fa-hard-drive',
        'Access Control' => 'fa-solid fa-fingerprint',
    ];

    return $map[$name] ?? 'fa-solid fa-tag';
}

/**
 * Categories for the sidebar. Reads from the DB; falls back to the same list
 * when the database is unavailable.
 */
function get_categories(): array
{
    $rows = db_fetch_all('SELECT CategoryID, CategoryName FROM CATEGORY ORDER BY CategoryID');
    if ($rows) {
        return $rows;
    }

    // Fallback mirrors the seed data in database/sebabd.sql.
    return [
        ['CategoryID' => 1,  'CategoryName' => 'Laptop'],
        ['CategoryID' => 2,  'CategoryName' => 'Desktop PC'],
        ['CategoryID' => 3,  'CategoryName' => 'All In One PC'],
        ['CategoryID' => 4,  'CategoryName' => 'Monitor'],
        ['CategoryID' => 5,  'CategoryName' => 'Printer'],
        ['CategoryID' => 6,  'CategoryName' => 'Photocopier'],
        ['CategoryID' => 7,  'CategoryName' => 'Projector'],
        ['CategoryID' => 8,  'CategoryName' => 'UPS'],
        ['CategoryID' => 9,  'CategoryName' => 'Mouse'],
        ['CategoryID' => 10, 'CategoryName' => 'Storage'],
        ['CategoryID' => 11, 'CategoryName' => 'Access Control'],
    ];
}

/**
 * Featured products for the storefront grid: one representative product per
 * category (lowest ProductID in each), so the homepage shows the full range.
 * Reads live data from the DB and merges in the presentation metadata; falls
 * back to a demo catalog when the database is unreachable.
 */
function get_featured_products(int $limit = 11): array
{
    $limit = max(1, min(50, $limit)); // sanitized — interpolated, not bound
    $rows = db_fetch_all(
        "SELECT p.ProductID, p.ProductName, p.Brand, p.Model, p.StandardPrice,
                p.IsSerialized, p.StockQty, p.DefaultWarrantyMonths,
                c.CategoryName
         FROM PRODUCT p
         JOIN CATEGORY c ON c.CategoryID = p.CategoryID
         JOIN (SELECT MIN(ProductID) AS PickID FROM PRODUCT GROUP BY CategoryID) pick
              ON pick.PickID = p.ProductID
         ORDER BY c.CategoryID
         LIMIT $limit"
    );

    $products = [];
    foreach ($rows as $row) {
        $meta = product_meta()[(int) $row['ProductID']] ?? [
            'image' => null,
            'alt'   => $row['ProductName'],
            'badge' => null,
            'blurb' => '',
            'sale'  => null,
        ];
        $products[] = array_merge($row, $meta);
    }

    if ($products) {
        return array_slice($products, 0, $limit);
    }

    // Offline fallback: one representative item per category, mirroring the
    // live query's per-category pick. [id, name, brand, category, price, serialized, qty]
    $fallback = [
        [8,  'HP 240 G8 Core i3 11th Gen 14" FHD Laptop',                          'HP',        'Laptop',         '53000.00', 0, 12],
        [3,  'Desktop PC 10th Gen Core i7 10700K',                                 'Star PC',   'Desktop PC',     '79900.00', 1, 0],
        [1,  'Dell Optiplex 24 7480 Core i5 10th Gen 23.8" Full HD All In One PC', 'Dell',      'All In One PC',  '89500.00', 1, 0],
        [12, 'HP M22f 22" FHD IPS Monitor',                                        'HP',        'Monitor',        '15800.00', 0, 15],
        [16, 'HP 107a Single Function Laser Printer',                              'HP',        'Printer',        '10500.00', 0, 6],
        [17, 'Toshiba e-Studio 2523A A3 Multifunction Digital Photocopier',        'Toshiba',   'Photocopier',    '42000.00', 1, 0],
        [18, 'Epson EB-W06 3700 Lumens WXGA 3LCD Office Projector',                'Epson',     'Projector',      '56000.00', 1, 0],
        [19, 'Prolink 650VA Offline UPS',                                          'Prolink',   'UPS',             '2700.00', 0, 9],
        [20, 'Gaming Mouse Havit MS1026 7-Button',                                 'Havit',     'Mouse',            '550.00', 0, 40],
        [25, 'SSD Kingspec 128GB 2.5" SATA III Solid State Disk',                  'Kingspec',  'Storage',         '2550.00', 0, 18],
        [26, 'Anviz FaceDeep 3 Cloud Access Control',                              'Anviz',     'Access Control', '23500.00', 1, 0],
    ];

    $products = [];
    foreach ($fallback as [$id, $name, $brand, $cat, $price, $serialized, $qty]) {
        $products[] = array_merge(
            [
                'ProductID' => $id, 'ProductName' => $name, 'Brand' => $brand,
                'CategoryName' => $cat, 'StandardPrice' => $price,
                'StockQty' => $qty, 'IsSerialized' => $serialized,
            ],
            product_meta()[$id]
        );
    }

    return array_slice($products, 0, $limit);
}

/**
 * Human stock line: serialized products track stock via PRODUCT_INSTANCE.
 */
function stock_line(array $product): string
{
    if (!empty($product['IsSerialized'])) {
        $inStock = db_fetch_all(
            "SELECT COUNT(*) AS n
             FROM PRODUCT_INSTANCE
             WHERE ProductID = :pid AND Status = 'In Stock'",
            [':pid' => (int) $product['ProductID']]
        );
        $n = (int) ($inStock[0]['n'] ?? 0);
        return $n > 0 ? $n . ' in stock' : 'Made to order';
    }

    $qty = (int) ($product['StockQty'] ?? 0);
    if ($qty > 10) return 'In stock';
    if ($qty > 0)  return 'Only ' . $qty . ' left';
    return 'Out of stock';
}

/**
 * Format a BDT price the way sebabd.com does: ৳ 89,500.00
 */
function bdt(float|string|null $amount): string
{
    return '৳ ' . number_format((float) $amount, 2);
}
