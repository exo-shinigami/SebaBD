-- ============================================================================
-- SebaBD — Total IT System Solution (sebabd.com)
-- ============================================================================
-- Application database. Schema below is the SEBABD FINAL VERSION (rev. 2)
-- DDL, imported verbatim; the CREATE DATABASE / USE lines and the seed data
-- are additions. Seed products, prices (BDT) and images mirror the real
-- sebabd.com catalog.
--
-- Import with (XAMPP):
--   C:\xampp\mysql\bin\mysql.exe -u root < database\sebabd.sql
-- ============================================================================

CREATE DATABASE IF NOT EXISTS sebabd
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE sebabd;

-- ============================================================
-- SEBABD SCHEMA — FINAL VERSION (rev. 2)
-- Changes applied vs. original draft:
--   1. CLIENT_BRANCH reinstated: Sebabd's B2B clients can have multiple
--      branches, so QUOTATION and INVOICE are issued per-branch again.
--      CLIENT.Address/Phone now represent the head-office/company-level
--      contact; CLIENT_BRANCH.BranchAddress/ContactNo represent each
--      individual branch. These are no longer redundant with each other.
--   2. INVOICE now has a CHECK constraint enforcing exactly one source
--      (QuotationNo XOR OrderID) instead of allowing both/neither.
--   3. PRODUCT.IsSerialized added to make explicit whether StockQty
--      (aggregate) or PRODUCT_INSTANCE rows (serialized) are authoritative
--      for a given product's stock.
--   4. QUOTATION_ITEM.WarrantyPeriod (VARCHAR) -> WarrantyMonths (INT),
--      consistent with PRODUCT.DefaultWarrantyMonths.
--   5. INVOICE_ITEM.WarrantyDuration removed — redundant with
--      PRODUCT_INSTANCE.ClientWarrantyExpiry, which is already linked via EquipmentID.
--   6. Explicit ON DELETE actions added to INVOICE_ITEM.EquipmentID and
--      PAYMENT_RECEIPT.InvoiceNo.
--   NOTE: TotalAmount / TotalPrice / RemainingBalance columns are kept as
--   stored "snapshot" values (not purely derived at query time) because
--   these are financial documents whose totals must stay fixed once issued,
--   even if product prices change later. They must be maintained by
--   application logic (or triggers) at write time.
-- ============================================================

-- 1. ROLES
CREATE TABLE ROLES (
    RoleID INT PRIMARY KEY,
    RoleName VARCHAR(50) NOT NULL UNIQUE
);

-- 2. USERS (Admin, Sales Manager, Inventory Staff, Buyer)
CREATE TABLE USERS (
    UserID INT PRIMARY KEY,
    RoleID INT NOT NULL,
    Username VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE,
    FullName VARCHAR(255) NOT NULL,
    Phone VARCHAR(50),
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (RoleID) REFERENCES ROLES(RoleID)
);

-- 3. CLIENT (Corporate B2B account, optionally linked to a login)
--    Address/Phone here = head office / company-level contact.
--    Per-branch details live in CLIENT_BRANCH below.
CREATE TABLE CLIENT (
    ClientID INT PRIMARY KEY,
    UserID INT UNIQUE,
    CompanyName VARCHAR(255) NOT NULL,
    ContactPerson VARCHAR(255),
    Email VARCHAR(255),
    Phone VARCHAR(50),
    Address TEXT,
    FOREIGN KEY (UserID) REFERENCES USERS(UserID) ON DELETE SET NULL
);

-- 4. CLIENT_BRANCH
CREATE TABLE CLIENT_BRANCH (
    BranchID INT PRIMARY KEY,
    ClientID INT NOT NULL,
    BranchName VARCHAR(255) NOT NULL,
    BranchAddress TEXT,
    ContactNo VARCHAR(50),
    FOREIGN KEY (ClientID) REFERENCES CLIENT(ClientID) ON DELETE CASCADE
);

-- 5. CATEGORY
CREATE TABLE CATEGORY (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(255) NOT NULL
);

-- 6. VENDOR
CREATE TABLE VENDOR (
    VendorID INT PRIMARY KEY,
    VendorName VARCHAR(255) NOT NULL,
    Location VARCHAR(255),
    ContactPhone VARCHAR(50)
);

-- 7. PRODUCT
CREATE TABLE PRODUCT (
    ProductID INT PRIMARY KEY,
    CategoryID INT NOT NULL,
    VendorID INT NOT NULL,
    ProductName VARCHAR(255) NOT NULL,
    Brand VARCHAR(100),
    Model VARCHAR(100),
    StandardPrice DECIMAL(12, 2) NOT NULL,
    IsSerialized BOOLEAN NOT NULL DEFAULT FALSE, -- TRUE = stock tracked via PRODUCT_INSTANCE, StockQty ignored
    StockQty INT DEFAULT 0,                       -- authoritative only when IsSerialized = FALSE
    DefaultWarrantyMonths INT DEFAULT 0,
    FOREIGN KEY (CategoryID) REFERENCES CATEGORY(CategoryID),
    FOREIGN KEY (VendorID) REFERENCES VENDOR(VendorID)
);

-- 8. PRODUCT_INSTANCE (Serialized items for warranty tracking)
CREATE TABLE PRODUCT_INSTANCE (
    EquipmentID INT PRIMARY KEY,
    ProductID INT NOT NULL,
    SerialNumber VARCHAR(100) UNIQUE NOT NULL,
    PurchaseDate DATE,
    VendorWarrantyExpiry DATE,
    ClientWarrantyExpiry DATE,
    Status VARCHAR(50) DEFAULT 'In Stock', -- 'In Stock', 'Assigned', 'RMA'
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID)
);

-- 9. ORDERS (Online e-commerce orders)
CREATE TABLE ORDERS (
    OrderID INT PRIMARY KEY,
    UserID INT NOT NULL,
    OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(12, 2) NOT NULL, -- snapshot, see header note
    OrderStatus VARCHAR(50) DEFAULT 'Pending', -- 'Pending', 'Processing', 'Completed', 'Cancelled'
    ShippingAddress TEXT,
    FOREIGN KEY (UserID) REFERENCES USERS(UserID)
);

-- 10. ORDER_ITEM
CREATE TABLE ORDER_ITEM (
    OrderItemID INT PRIMARY KEY,
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(12, 2) NOT NULL,  -- price snapshot at time of order
    TotalPrice DECIMAL(12, 2) NOT NULL, -- Quantity * UnitPrice, snapshot
    FOREIGN KEY (OrderID) REFERENCES ORDERS(OrderID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID)
);

-- 11. QUOTATION (B2B corporate quotations, issued per branch)
CREATE TABLE QUOTATION (
    QuotationNo INT PRIMARY KEY,
    BranchID INT NOT NULL,
    QuotationDate DATE NOT NULL,
    Subject VARCHAR(255),
    TotalAmount DECIMAL(12, 2) NOT NULL, -- snapshot
    AmountInWords TEXT,
    Status VARCHAR(50) DEFAULT 'Pending', -- 'Pending', 'Accepted', 'Rejected'
    FOREIGN KEY (BranchID) REFERENCES CLIENT_BRANCH(BranchID)
);

-- 12. QUOTATION_ITEM
CREATE TABLE QUOTATION_ITEM (
    QuotationItemID INT PRIMARY KEY,
    QuotationNo INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(12, 2) NOT NULL,
    TotalPrice DECIMAL(12, 2) NOT NULL,
    WarrantyMonths INT, -- quoted term before a physical unit is assigned
    FOREIGN KEY (QuotationNo) REFERENCES QUOTATION(QuotationNo) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID)
);

-- 13. INVOICE (from an accepted quotation OR an e-commerce order — never both)
--     BranchID is only relevant/set for quotation-sourced (B2B) invoices;
--     order-sourced (e-commerce) invoices leave it NULL.
CREATE TABLE INVOICE (
    InvoiceNo INT PRIMARY KEY,
    BranchID INT,
    QuotationNo INT UNIQUE,
    OrderID INT UNIQUE,
    InvoiceDate DATE NOT NULL,
    PaymentStatus VARCHAR(50) DEFAULT 'DUE', -- 'DUE', 'PAID'
    TotalAmount DECIMAL(12, 2) NOT NULL,     -- snapshot
    RemainingBalance DECIMAL(12, 2) NOT NULL, -- maintained on each PAYMENT_RECEIPT insert
    AmountInWords TEXT,
    FOREIGN KEY (BranchID) REFERENCES CLIENT_BRANCH(BranchID),
    FOREIGN KEY (QuotationNo) REFERENCES QUOTATION(QuotationNo),
    FOREIGN KEY (OrderID) REFERENCES ORDERS(OrderID),
    CONSTRAINT chk_invoice_single_source CHECK (
        (QuotationNo IS NOT NULL AND OrderID IS NULL) OR
        (QuotationNo IS NULL AND OrderID IS NOT NULL)
    )
);

-- 14. INVOICE_ITEM
CREATE TABLE INVOICE_ITEM (
    InvoiceItemID INT PRIMARY KEY,
    InvoiceNo INT NOT NULL,
    ProductID INT NOT NULL,
    EquipmentID INT, -- specific serialized unit sold, if applicable
    Quantity INT NOT NULL,
    SoldUnitPrice DECIMAL(12, 2) NOT NULL,
    TotalPrice DECIMAL(12, 2) NOT NULL,
    -- Warranty info comes from PRODUCT_INSTANCE.ClientWarrantyExpiry via EquipmentID;
    -- no separate WarrantyDuration column needed here.
    FOREIGN KEY (InvoiceNo) REFERENCES INVOICE(InvoiceNo) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID),
    FOREIGN KEY (EquipmentID) REFERENCES PRODUCT_INSTANCE(EquipmentID) ON DELETE SET NULL
);

-- 15. PAYMENT_RECEIPT
CREATE TABLE PAYMENT_RECEIPT (
    ReceiptNo INT PRIMARY KEY,
    InvoiceNo INT NOT NULL,
    ReceiptDate DATE NOT NULL,
    AmountReceived DECIMAL(12, 2) NOT NULL,
    PaymentMethod VARCHAR(50), -- 'Cash', 'Bank Transfer', 'Credit Card', 'Mobile Banking'
    RemainingDueAfterReceipt DECIMAL(12, 2) NOT NULL, -- balance snapshot at this payment
    ReceivedBy VARCHAR(255),
    FOREIGN KEY (InvoiceNo) REFERENCES INVOICE(InvoiceNo) ON DELETE RESTRICT
);

-- 16. PURCHASE_ORDER (Vendor supply requests)
CREATE TABLE PURCHASE_ORDER (
    PONo INT PRIMARY KEY,
    VendorID INT NOT NULL,
    PODate DATE NOT NULL,
    TotalAmount DECIMAL(12, 2) NOT NULL, -- snapshot
    Terms TEXT,
    FOREIGN KEY (VendorID) REFERENCES VENDOR(VendorID)
);

-- 17. PO_ITEM
CREATE TABLE PO_ITEM (
    POItemID INT PRIMARY KEY,
    PONo INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    WholesaleUnitPrice DECIMAL(12, 2) NOT NULL,
    TotalPrice DECIMAL(12, 2) NOT NULL,
    FOREIGN KEY (PONo) REFERENCES PURCHASE_ORDER(PONo) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID)
);

-- ============================================================================
-- SEED DATA — real sebabd.com catalog, prices in BDT (৳)
-- Passwords are real bcrypt hashes so seeded logins actually work:
--   admin / admin123,  sales / sales123,  stock / stock123,  buyer / buyer123
-- ============================================================================

INSERT INTO ROLES (RoleID, RoleName) VALUES
    (1, 'Admin'),
    (2, 'Sales Manager'),
    (3, 'Inventory Staff'),
    (4, 'Buyer');

INSERT INTO USERS (UserID, RoleID, Username, PasswordHash, Email, FullName, Phone) VALUES
    (1, 1, 'admin', '$2y$10$OqZWpkVTtjJzdRGEtXvp9edlbMB/PzmLonS5DFCeOcdClJ.IfVVKm', 'admin@sebabd.com',  'System Administrator', '+880 1711 000 001'),
    (2, 2, 'sales', '$2y$10$eDaJsZ22IuJmK4p9pEGgw.4E/4ss51jW/P4M3UuFE/CP2y2InqJ6e', 'sales@sebabd.com',  'Farhana Akter',        '+880 1711 000 002'),
    (3, 3, 'stock', '$2y$10$nkvsZQaDu9k8vydlWzq1ZeTXAtNzHUWRGJb8gLC26BQ9g85e05N2e', 'stock@sebabd.com',  'Tanvir Hasan',         '+880 1711 000 003'),
    (4, 4, 'buyer', '$2y$10$zLMVgCGgoi2.bz4qbdg94uZzY0l/kAMq0w0ogfrB/rPl5Btfldmaq', 'buyer@sebabd.com',  'Rafi Karim',           '+880 1711 000 004');

INSERT INTO CLIENT (ClientID, UserID, CompanyName, ContactPerson, Email, Phone, Address) VALUES
    (1, 4, 'Vertex Software Ltd.', 'Nusrat Jahan', 'procurement@vertexsoft.com', '+880 1711 100 111', 'House 12, Road 5, Gulshan-1, Dhaka 1212');

INSERT INTO CLIENT_BRANCH (BranchID, ClientID, BranchName, BranchAddress, ContactNo) VALUES
    (1, 1, 'Head Office — Gulshan', 'House 12, Road 5, Gulshan-1, Dhaka 1212', '+880 1711 100 111'),
    (2, 1, 'Uttara Dev Center',     'Plot 15, Sector 7, Uttara, Dhaka 1230',   '+880 1711 100 222');

INSERT INTO CATEGORY (CategoryID, CategoryName) VALUES
    (1,  'Laptop'),
    (2,  'Desktop PC'),
    (3,  'All In One PC'),
    (4,  'Monitor'),
    (5,  'Printer'),
    (6,  'Photocopier'),
    (7,  'Projector'),
    (8,  'UPS'),
    (9,  'Mouse'),
    (10, 'Storage'),
    (11, 'Access Control');

INSERT INTO VENDOR (VendorID, VendorName, Location, ContactPhone) VALUES
    (1, 'Dell Bangladesh Distribution',   'Dhaka',    '+880 1711 200 001'),
    (2, 'HP Bangladesh Distribution',     'Dhaka',    '+880 1711 200 002'),
    (3, 'Asus Bangladesh Distribution',   'Dhaka',    '+880 1711 200 003'),
    (4, 'Lenovo Bangladesh Distribution', 'Dhaka',    '+880 1711 200 004'),
    (5, 'Anviz International (USA)',      'USA',      '+1 949 261 8998'),
    (6, 'Epson Singapore Pte. Ltd.',      'Singapore','+65 6586 0300'),
    (7, 'Toshiba TEC Singapore',          'Singapore','+65 6270 3777'),
    (8, 'Global IT Trading',              'Dhaka',    '+880 1711 200 008');

-- Real sebabd.com catalog. StandardPrice = current selling price (৳).
INSERT INTO PRODUCT (ProductID, CategoryID, VendorID, ProductName, Brand, Model, StandardPrice, IsSerialized, StockQty, DefaultWarrantyMonths) VALUES
    (1,  3,  1, 'Dell Optiplex 24 7480 Core i5 10th Gen 23.8" Full HD All In One PC', 'Dell',    'Optiplex 7480',  89500.00, TRUE,  0, 36),
    (2,  3,  1, 'Dell Optiplex 3280 Core i3 10th Gen 21.5 All-In-One PC',             'Dell',    'Optiplex 3280',  50800.00, TRUE,  0, 36),
    (3,  2,  8, 'Desktop PC 10th Gen Core i7 10700K',                                    'Star PC', 'i7-10700K',      79900.00, TRUE,  0, 36),
    (4,  2,  8, 'Desktop PC 10th Gen Core i7 10700',                                    'Star PC', 'i7-10700',       52500.00, TRUE,  0, 36),
    (5,  2,  8, 'Desktop PC 10th Gen Core i5 10500',                                    'Star PC', 'i5-10500',       37500.00, TRUE,  0, 36),
    (6,  2,  8, 'Desktop PC 10th Gen Core i3 10100',                                    'Star PC', 'i3-10100',       26990.00, TRUE,  0, 36),
    (7,  2,  2, 'HP 280 Pro G6 MT Core i3 10th Gen Microtower PC',                      'HP',      '280 Pro G6 MT',  46000.00, FALSE, 7, 36),
    (8,  1,  2, 'HP 240 G8 Core i3 11th Gen 14" FHD Laptop',                            'HP',      '240 G8',         53000.00, FALSE, 12, 24),
    (9,  1,  3, 'Asus VivoBook 14 X415FA Core i3 10th Gen 14" Laptop',                  'Asus',    'X415FA',         44500.00, FALSE, 9, 24),
    (10, 1,  4, 'Lenovo IdeaPad Slim 3i Core i3 10th Gen 15.6" Laptop',                 'Lenovo',  'IdeaPad Slim 3i',43500.00, FALSE, 14, 24),
    (11, 1,  1, 'Dell Vostro 15 3500 Core i3 11th Gen 15.6" Laptop',                    'Dell',    'Vostro 15 3500', 44500.00, FALSE, 8, 24),
    (12, 4,  2, 'HP M22f 22" FHD IPS Monitor',                                          'HP',      'M22f',           15800.00, FALSE, 15, 36),
    (13, 4,  8, 'Xiaomi Redmi RMMNT215NF 21.45" FHD Monitor',                           'Xiaomi',  'RMMNT215NF',      8600.00, FALSE, 20, 36),
    (14, 4,  8, 'Value-Top T22VF 21.5" FHD LED Monitor',                                'Value-Top','T22VF',          8900.00, FALSE, 18, 36),
    (15, 4,  1, 'Dell D1918H 18.5 Inch LED Monitor (VGA, HDMI)',                        'Dell',    'D1918H',          9100.00, FALSE, 10, 36),
    (16, 5,  2, 'HP 107a Single Function Laser Printer',                                'HP',      '107a',           10500.00, FALSE, 6, 12),
    (17, 6,  7, 'Toshiba e-Studio 2523A A3 Multifunction Digital Photocopier',          'Toshiba', 'e-Studio 2523A', 42000.00, TRUE,  0, 12),
    (18, 7,  6, 'Epson EB-W06 3700 Lumens WXGA 3LCD Office Projector',                  'Epson',   'EB-W06',         56000.00, TRUE,  0, 12),
    (19, 8,  8, 'Prolink 650VA Offline UPS',                                            'Prolink', 'PB650',           2700.00, FALSE, 9, 12),
    (20, 9,  8, 'Gaming Mouse Havit MS1026 7-Button',                                   'Havit',   'MS1026',            550.00, FALSE, 40, 12),
    (21, 9,  8, 'Wireless Mouse A4tech FG10 Optical 2000 DPI',                          'A4Tech',  'FG10',              650.00, FALSE, 25, 12),
    (22, 9,  8, 'A4TECH OP-620D 2X Click Optical Mouse',                                'A4Tech',  'OP-620D',           350.00, FALSE, 60, 12),
    (23, 9,  8, 'Logitech M90 USB Contoured Shape Mouse',                               'Logitech','M90',               400.00, FALSE, 30, 12),
    (24, 9,  8, 'Micropack M101 Optical USB Mouse',                                     'Micropack','M101',              250.00, FALSE, 45, 12),
    (25, 10, 8, 'SSD Kingspec 128GB 2.5" SATA III Solid State Disk',                    'Kingspec','P3-128',           2550.00, FALSE, 18, 36),
    (26, 11, 5, 'Anviz FaceDeep 3 Cloud Access Control',                                'Anviz',   'FaceDeep 3',      23500.00, TRUE,  0, 12),
    (27, 11, 5, 'Anviz W2 Pro Cloud Access Control',                                    'Anviz',   'W2 Pro',          11500.00, TRUE,  0, 12),
    (28, 11, 5, 'Anviz W1 Pro Cloud Access Control',                                    'Anviz',   'W1 Pro',          10500.00, TRUE,  0, 12);

-- Serialized units (warranty tracked per unit).
INSERT INTO PRODUCT_INSTANCE (EquipmentID, ProductID, SerialNumber, PurchaseDate, VendorWarrantyExpiry, ClientWarrantyExpiry, Status) VALUES
    (1,  1, 'SN-OPT7480-0001',  '2026-01-15', '2029-01-15', NULL,         'In Stock'),
    (2,  1, 'SN-OPT7480-0002',  '2026-01-15', '2029-01-15', NULL,         'In Stock'),
    (3,  3, 'SN-I710700K-0001', '2026-02-10', '2029-02-10', NULL,         'In Stock'),
    (4,  3, 'SN-I710700K-0002', '2026-02-10', '2029-02-10', NULL,         'In Stock'),
    (5,  3, 'SN-I710700K-0003', '2026-02-10', '2029-02-10', NULL,         'In Stock'),
    (6,  3, 'SN-I710700K-0004', '2025-12-05', '2028-12-05', '2028-12-05', 'Assigned'),
    (7,  4, 'SN-I710700-0001',  '2026-03-01', '2029-03-01', NULL,         'In Stock'),
    (8,  4, 'SN-I710700-0002',  '2026-03-01', '2029-03-01', NULL,         'In Stock'),
    (9,  17, 'SN-EST2523A-001', '2026-04-20', '2027-04-20', NULL,         'In Stock'),
    (10, 18, 'SN-EBW06-0001',   '2026-03-18', '2027-03-18', NULL,         'In Stock'),
    (11, 18, 'SN-EBW06-0002',   '2026-03-18', '2027-03-18', NULL,         'In Stock'),
    (12, 26, 'SN-FD3-0001',     '2026-05-02', '2027-05-02', NULL,         'In Stock'),
    (13, 26, 'SN-FD3-0002',     '2026-05-02', '2027-05-02', NULL,         'In Stock'),
    (14, 26, 'SN-FD3-0003',     '2026-05-02', '2027-05-02', NULL,         'In Stock'),
    (15, 26, 'SN-FD3-0004',     '2025-11-11', '2026-11-11', NULL,         'RMA'),
    (16, 27, 'SN-W2P-0001',     '2026-05-02', '2027-05-02', NULL,         'In Stock'),
    (17, 27, 'SN-W2P-0002',     '2026-05-02', '2027-05-02', NULL,         'In Stock'),
    (18, 28, 'SN-W1P-0001',     '2026-05-02', '2027-05-02', NULL,         'In Stock'),
    (19, 28, 'SN-W1P-0002',     '2026-05-02', '2027-05-02', NULL,         'In Stock');

-- One completed online order by the buyer account.
INSERT INTO ORDERS (OrderID, UserID, OrderDate, TotalAmount, OrderStatus, ShippingAddress) VALUES
    (1, 4, '2026-08-12 14:30:00', 19800.00, 'Completed', 'House 22, Road 10, Dhanmondi, Dhaka 1209');

INSERT INTO ORDER_ITEM (OrderItemID, OrderID, ProductID, Quantity, UnitPrice, TotalPrice) VALUES
    (1, 1, 12, 1, 15800.00, 15800.00),
    (2, 1, 20, 2,   550.00,  1100.00),
    (3, 1, 22, 1,   350.00,   350.00),
    (4, 1, 25, 1,  2550.00,  2550.00);

-- B2B quotation issued to Vertex Software's Gulshan branch, later invoiced.
INSERT INTO QUOTATION (QuotationNo, BranchID, QuotationDate, Subject, TotalAmount, AmountInWords, Status) VALUES
    (1, 1, '2026-09-10', 'Office IT setup — 10 workstations', 575000.00,
     'Five lakh seventy-five thousand taka only', 'Accepted');

INSERT INTO QUOTATION_ITEM (QuotationItemID, QuotationNo, ProductID, Quantity, UnitPrice, TotalPrice, WarrantyMonths) VALUES
    (1, 1, 5,  10, 37500.00, 375000.00, 36),
    (2, 1, 12, 10, 15800.00, 158000.00, 36),
    (3, 1, 16, 2,  10500.00,  21000.00, 12),
    (4, 1, 28, 2,  10500.00,  21000.00, 12);

-- Invoice #1: from the accepted quotation (B2B, branch-linked, part paid).
INSERT INTO INVOICE (InvoiceNo, BranchID, QuotationNo, OrderID, InvoiceDate, PaymentStatus, TotalAmount, RemainingBalance, AmountInWords) VALUES
    (1, 1, 1, NULL, '2026-09-12', 'DUE', 575000.00, 175000.00,
     'Five lakh seventy-five thousand taka only'),
    (2, NULL, NULL, 1, '2026-08-13', 'PAID', 19800.00, 0.00,
     'Nineteen thousand eight hundred taka only');

INSERT INTO INVOICE_ITEM (InvoiceItemID, InvoiceNo, ProductID, EquipmentID, Quantity, SoldUnitPrice, TotalPrice) VALUES
    (1,  1, 5,  NULL, 10, 37500.00, 375000.00),
    (2,  1, 12, NULL, 10, 15800.00, 158000.00),
    (3,  1, 16, NULL, 2,  10500.00,  21000.00),
    (4,  1, 28, NULL, 2,  10500.00,  21000.00),
    (5,  2, 12, NULL, 1,  15800.00,  15800.00),
    (6,  2, 20, NULL, 2,    550.00,   1100.00),
    (7,  2, 22, NULL, 1,    350.00,    350.00),
    (8,  2, 25, NULL, 1,   2550.00,   2550.00);

INSERT INTO PAYMENT_RECEIPT (ReceiptNo, InvoiceNo, ReceiptDate, AmountReceived, PaymentMethod, RemainingDueAfterReceipt, ReceivedBy) VALUES
    (1, 1, '2026-09-12', 400000.00, 'Bank Transfer', 175000.00, 'Farhana Akter'),
    (2, 2, '2026-08-13',  19800.00, 'Credit Card',        0.00, 'Farhana Akter');

-- Restock purchase orders to vendors.
INSERT INTO PURCHASE_ORDER (PONo, VendorID, PODate, TotalAmount, Terms) VALUES
    (1, 3, '2026-09-05', 360000.00, 'Net 30; freight included'),
    (2, 8, '2026-09-15',  14000.00, 'Net 15');

INSERT INTO PO_ITEM (POItemID, PONo, ProductID, Quantity, WholesaleUnitPrice, TotalPrice) VALUES
    (1, 1, 9,  10, 36000.00, 360000.00),
    (2, 2, 20, 20,   400.00,   8000.00),
    (3, 2, 23, 20,   300.00,   6000.00);
