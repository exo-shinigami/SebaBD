<?php
/**
 * SebaBD — application configuration.
 * Adjust these values to match your MySQL setup (XAMPP defaults shown).
 */
return [
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'name'     => 'sebabd',
        'user'     => 'root',
        'password' => '',          // XAMPP default: empty
        'charset'  => 'utf8mb4',
    ],
    'site' => [
        'name'     => 'SebaBD',
        'tagline'  => 'Total IT System Solution',
        'currency' => '৳',
    ],
];
