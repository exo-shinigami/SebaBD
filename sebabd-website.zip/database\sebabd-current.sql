-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: sebabd
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sebabd`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sebabd` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `sebabd`;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Laptop'),(2,'Desktop PC'),(3,'All In One PC'),(4,'Monitor'),(5,'Printer'),(6,'Photocopier'),(7,'Projector'),(8,'UPS'),(9,'Mouse'),(10,'Storage'),(11,'Access Control');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `ClientID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `CompanyName` varchar(255) NOT NULL,
  `ContactPerson` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  PRIMARY KEY (`ClientID`),
  UNIQUE KEY `UserID` (`UserID`),
  CONSTRAINT `client_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,4,'Vertex Software Ltd.','Nusrat Jahan','procurement@vertexsoft.com','+880 1711 100 111','House 12, Road 5, Gulshan-1, Dhaka 1212'),(2,6,'Acme Bangladesh Ltd','Ms. Sultana','procure@acme.com.bd','880 1811 223344','Level 5, Bay\'s Galleria, Gulshan 1, Dhaka'),(3,NULL,'Walk-in / Retail Customers','Rafi Karim','buyer@sebabd.com',NULL,'Dhaka, Bangladesh');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_branch`
--

DROP TABLE IF EXISTS `client_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_branch` (
  `BranchID` int(11) NOT NULL,
  `ClientID` int(11) NOT NULL,
  `BranchName` varchar(255) NOT NULL,
  `BranchAddress` text DEFAULT NULL,
  `ContactNo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`BranchID`),
  KEY `ClientID` (`ClientID`),
  CONSTRAINT `client_branch_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `client` (`ClientID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_branch`
--

LOCK TABLES `client_branch` WRITE;
/*!40000 ALTER TABLE `client_branch` DISABLE KEYS */;
INSERT INTO `client_branch` VALUES (1,1,'Head Office — Gulshan','House 12, Road 5, Gulshan-1, Dhaka 1212','+880 1711 100 111'),(2,1,'Uttara Dev Center','Plot 15, Sector 7, Uttara, Dhaka 1230','+880 1711 100 222'),(3,2,'Head Office','Level 5, Bay\'s Galleria, Gulshan 1, Dhaka','880 1811 223344'),(4,3,'Walk-in Branch','Dhaka, Bangladesh','01711000444');
/*!40000 ALTER TABLE `client_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `InvoiceNo` int(11) NOT NULL,
  `BranchID` int(11) DEFAULT NULL,
  `QuotationNo` int(11) DEFAULT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `InvoiceDate` date NOT NULL,
  `PaymentStatus` varchar(50) DEFAULT 'DUE',
  `TotalAmount` decimal(12,2) NOT NULL,
  `RemainingBalance` decimal(12,2) NOT NULL,
  `AmountInWords` text DEFAULT NULL,
  PRIMARY KEY (`InvoiceNo`),
  UNIQUE KEY `QuotationNo` (`QuotationNo`),
  UNIQUE KEY `OrderID` (`OrderID`),
  KEY `BranchID` (`BranchID`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`BranchID`) REFERENCES `client_branch` (`BranchID`),
  CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`QuotationNo`) REFERENCES `quotation` (`QuotationNo`),
  CONSTRAINT `invoice_ibfk_3` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  CONSTRAINT `chk_invoice_single_source` CHECK (`QuotationNo` is not null and `OrderID` is null or `QuotationNo` is null and `OrderID` is not null)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,1,1,NULL,'2026-09-12','DUE',575000.00,175000.00,'Five lakh seventy-five thousand taka only'),(2,NULL,NULL,1,'2026-08-13','PAID',19800.00,0.00,'Nineteen thousand eight hundred taka only');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_item`
--

DROP TABLE IF EXISTS `invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_item` (
  `InvoiceItemID` int(11) NOT NULL,
  `InvoiceNo` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `EquipmentID` int(11) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `SoldUnitPrice` decimal(12,2) NOT NULL,
  `TotalPrice` decimal(12,2) NOT NULL,
  PRIMARY KEY (`InvoiceItemID`),
  KEY `InvoiceNo` (`InvoiceNo`),
  KEY `ProductID` (`ProductID`),
  KEY `EquipmentID` (`EquipmentID`),
  CONSTRAINT `invoice_item_ibfk_1` FOREIGN KEY (`InvoiceNo`) REFERENCES `invoice` (`InvoiceNo`) ON DELETE CASCADE,
  CONSTRAINT `invoice_item_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`),
  CONSTRAINT `invoice_item_ibfk_3` FOREIGN KEY (`EquipmentID`) REFERENCES `product_instance` (`EquipmentID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_item`
--

LOCK TABLES `invoice_item` WRITE;
/*!40000 ALTER TABLE `invoice_item` DISABLE KEYS */;
INSERT INTO `invoice_item` VALUES (1,1,5,NULL,10,37500.00,375000.00),(2,1,12,NULL,10,15800.00,158000.00),(3,1,16,NULL,2,10500.00,21000.00),(4,1,28,NULL,2,10500.00,21000.00),(5,2,12,NULL,1,15800.00,15800.00),(6,2,20,NULL,2,550.00,1100.00),(7,2,22,NULL,1,350.00,350.00),(8,2,25,NULL,1,2550.00,2550.00);
/*!40000 ALTER TABLE `invoice_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item` (
  `OrderItemID` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `UnitPrice` decimal(12,2) NOT NULL,
  `TotalPrice` decimal(12,2) NOT NULL,
  PRIMARY KEY (`OrderItemID`),
  KEY `OrderID` (`OrderID`),
  KEY `ProductID` (`ProductID`),
  CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`) ON DELETE CASCADE,
  CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES (1,1,12,1,15800.00,15800.00),(2,1,20,2,550.00,1100.00),(3,1,22,1,350.00,350.00),(4,1,25,1,2550.00,2550.00),(5,2,12,2,15800.00,31600.00),(6,2,20,1,550.00,550.00);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `OrderDate` datetime DEFAULT current_timestamp(),
  `TotalAmount` decimal(12,2) NOT NULL,
  `OrderStatus` varchar(50) DEFAULT 'Pending',
  `ShippingAddress` text DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,4,'2026-08-12 14:30:00',19800.00,'Completed','House 22, Road 10, Dhanmondi, Dhaka 1209'),(2,4,'2026-09-24 23:01:37',32150.00,'Pending','House 44, Road 11, Dhanmondi, Dhaka 1209');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_receipt`
--

DROP TABLE IF EXISTS `payment_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_receipt` (
  `ReceiptNo` int(11) NOT NULL,
  `InvoiceNo` int(11) NOT NULL,
  `ReceiptDate` date NOT NULL,
  `AmountReceived` decimal(12,2) NOT NULL,
  `PaymentMethod` varchar(50) DEFAULT NULL,
  `RemainingDueAfterReceipt` decimal(12,2) NOT NULL,
  `ReceivedBy` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ReceiptNo`),
  KEY `InvoiceNo` (`InvoiceNo`),
  CONSTRAINT `payment_receipt_ibfk_1` FOREIGN KEY (`InvoiceNo`) REFERENCES `invoice` (`InvoiceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_receipt`
--

LOCK TABLES `payment_receipt` WRITE;
/*!40000 ALTER TABLE `payment_receipt` DISABLE KEYS */;
INSERT INTO `payment_receipt` VALUES (1,1,'2026-09-12',400000.00,'Bank Transfer',175000.00,'Farhana Akter'),(2,2,'2026-08-13',19800.00,'Credit Card',0.00,'Farhana Akter');
/*!40000 ALTER TABLE `payment_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `po_item`
--

DROP TABLE IF EXISTS `po_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `po_item` (
  `POItemID` int(11) NOT NULL,
  `PONo` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `WholesaleUnitPrice` decimal(12,2) NOT NULL,
  `TotalPrice` decimal(12,2) NOT NULL,
  PRIMARY KEY (`POItemID`),
  KEY `PONo` (`PONo`),
  KEY `ProductID` (`ProductID`),
  CONSTRAINT `po_item_ibfk_1` FOREIGN KEY (`PONo`) REFERENCES `purchase_order` (`PONo`) ON DELETE CASCADE,
  CONSTRAINT `po_item_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `po_item`
--

LOCK TABLES `po_item` WRITE;
/*!40000 ALTER TABLE `po_item` DISABLE KEYS */;
INSERT INTO `po_item` VALUES (1,1,9,10,36000.00,360000.00),(2,2,20,20,400.00,8000.00),(3,2,23,20,300.00,6000.00);
/*!40000 ALTER TABLE `po_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `VendorID` int(11) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Brand` varchar(100) DEFAULT NULL,
  `Model` varchar(100) DEFAULT NULL,
  `StandardPrice` decimal(12,2) NOT NULL,
  `IsSerialized` tinyint(1) NOT NULL DEFAULT 0,
  `StockQty` int(11) DEFAULT 0,
  `DefaultWarrantyMonths` int(11) DEFAULT 0,
  PRIMARY KEY (`ProductID`),
  KEY `CategoryID` (`CategoryID`),
  KEY `VendorID` (`VendorID`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`),
  CONSTRAINT `product_ibfk_2` FOREIGN KEY (`VendorID`) REFERENCES `vendor` (`VendorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,3,1,'Dell Optiplex 24 7480 Core i5 10th Gen 23.8\" Full HD All In One PC','Dell','Optiplex 7480',89500.00,1,0,36),(2,3,1,'Dell Optiplex 3280 Core i3 10th Gen 21.5 All-In-One PC','Dell','Optiplex 3280',50800.00,1,0,36),(3,2,8,'Desktop PC 10th Gen Core i7 10700K','Star PC','i7-10700K',79900.00,1,0,36),(4,2,8,'Desktop PC 10th Gen Core i7 10700','Star PC','i7-10700',52500.00,1,0,36),(5,2,8,'Desktop PC 10th Gen Core i5 10500','Star PC','i5-10500',37500.00,1,0,36),(6,2,8,'Desktop PC 10th Gen Core i3 10100','Star PC','i3-10100',26990.00,1,0,36),(7,2,2,'HP 280 Pro G6 MT Core i3 10th Gen Microtower PC','HP','280 Pro G6 MT',46000.00,0,7,36),(8,1,2,'HP 240 G8 Core i3 11th Gen 14\" FHD Laptop','HP','240 G8',53000.00,0,12,24),(9,1,3,'Asus VivoBook 14 X415FA Core i3 10th Gen 14\" Laptop','Asus','X415FA',44500.00,0,9,24),(10,1,4,'Lenovo IdeaPad Slim 3i Core i3 10th Gen 15.6\" Laptop','Lenovo','IdeaPad Slim 3i',43500.00,0,14,24),(11,1,1,'Dell Vostro 15 3500 Core i3 11th Gen 15.6\" Laptop','Dell','Vostro 15 3500',44500.00,0,8,24),(12,4,2,'HP M22f 22\" FHD IPS Monitor','HP','M22f',15800.00,0,15,36),(13,4,8,'Xiaomi Redmi RMMNT215NF 21.45\" FHD Monitor','Xiaomi','RMMNT215NF',8600.00,0,20,36),(14,4,8,'Value-Top T22VF 21.5\" FHD LED Monitor','Value-Top','T22VF',8900.00,0,18,36),(15,4,1,'Dell D1918H 18.5 Inch LED Monitor (VGA, HDMI)','Dell','D1918H',9100.00,0,10,36),(16,5,2,'HP 107a Single Function Laser Printer','HP','107a',10500.00,0,6,12),(17,6,7,'Toshiba e-Studio 2523A A3 Multifunction Digital Photocopier','Toshiba','e-Studio 2523A',42000.00,1,0,12),(18,7,6,'Epson EB-W06 3700 Lumens WXGA 3LCD Office Projector','Epson','EB-W06',56000.00,1,0,12),(19,8,8,'Prolink 650VA Offline UPS','Prolink','PB650',2700.00,0,9,12),(20,9,8,'Gaming Mouse Havit MS1026 7-Button','Havit','MS1026',550.00,0,40,12),(21,9,8,'Wireless Mouse A4tech FG10 Optical 2000 DPI','A4Tech','FG10',650.00,0,25,12),(22,9,8,'A4TECH OP-620D 2X Click Optical Mouse','A4Tech','OP-620D',350.00,0,60,12),(23,9,8,'Logitech M90 USB Contoured Shape Mouse','Logitech','M90',400.00,0,30,12),(24,9,8,'Micropack M101 Optical USB Mouse','Micropack','M101',250.00,0,45,12),(25,10,8,'SSD Kingspec 128GB 2.5\" SATA III Solid State Disk','Kingspec','P3-128',2550.00,0,18,36),(26,11,5,'Anviz FaceDeep 3 Cloud Access Control','Anviz','FaceDeep 3',23500.00,1,0,12),(27,11,5,'Anviz W2 Pro Cloud Access Control','Anviz','W2 Pro',11500.00,1,0,12),(28,11,5,'Anviz W1 Pro Cloud Access Control','Anviz','W1 Pro',10500.00,1,0,12);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_instance`
--

DROP TABLE IF EXISTS `product_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_instance` (
  `EquipmentID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `SerialNumber` varchar(100) NOT NULL,
  `PurchaseDate` date DEFAULT NULL,
  `VendorWarrantyExpiry` date DEFAULT NULL,
  `ClientWarrantyExpiry` date DEFAULT NULL,
  `Status` varchar(50) DEFAULT 'In Stock',
  PRIMARY KEY (`EquipmentID`),
  UNIQUE KEY `SerialNumber` (`SerialNumber`),
  KEY `ProductID` (`ProductID`),
  CONSTRAINT `product_instance_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_instance`
--

LOCK TABLES `product_instance` WRITE;
/*!40000 ALTER TABLE `product_instance` DISABLE KEYS */;
INSERT INTO `product_instance` VALUES (1,1,'SN-OPT7480-0001','2026-01-15','2029-01-15',NULL,'In Stock'),(2,1,'SN-OPT7480-0002','2026-01-15','2029-01-15',NULL,'In Stock'),(3,3,'SN-I710700K-0001','2026-02-10','2029-02-10',NULL,'In Stock'),(4,3,'SN-I710700K-0002','2026-02-10','2029-02-10',NULL,'In Stock'),(5,3,'SN-I710700K-0003','2026-02-10','2029-02-10',NULL,'In Stock'),(6,3,'SN-I710700K-0004','2025-12-05','2028-12-05','2028-12-05','Assigned'),(7,4,'SN-I710700-0001','2026-03-01','2029-03-01',NULL,'In Stock'),(8,4,'SN-I710700-0002','2026-03-01','2029-03-01',NULL,'In Stock'),(9,17,'SN-EST2523A-001','2026-04-20','2027-04-20',NULL,'In Stock'),(10,18,'SN-EBW06-0001','2026-03-18','2027-03-18',NULL,'In Stock'),(11,18,'SN-EBW06-0002','2026-03-18','2027-03-18',NULL,'In Stock'),(12,26,'SN-FD3-0001','2026-05-02','2027-05-02',NULL,'In Stock'),(13,26,'SN-FD3-0002','2026-05-02','2027-05-02',NULL,'In Stock'),(14,26,'SN-FD3-0003','2026-05-02','2027-05-02',NULL,'In Stock'),(15,26,'SN-FD3-0004','2025-11-11','2026-11-11',NULL,'RMA'),(16,27,'SN-W2P-0001','2026-05-02','2027-05-02',NULL,'In Stock'),(17,27,'SN-W2P-0002','2026-05-02','2027-05-02',NULL,'In Stock'),(18,28,'SN-W1P-0001','2026-05-02','2027-05-02',NULL,'In Stock'),(19,28,'SN-W1P-0002','2026-05-02','2027-05-02',NULL,'In Stock');
/*!40000 ALTER TABLE `product_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order` (
  `PONo` int(11) NOT NULL,
  `VendorID` int(11) NOT NULL,
  `PODate` date NOT NULL,
  `TotalAmount` decimal(12,2) NOT NULL,
  `Terms` text DEFAULT NULL,
  PRIMARY KEY (`PONo`),
  KEY `VendorID` (`VendorID`),
  CONSTRAINT `purchase_order_ibfk_1` FOREIGN KEY (`VendorID`) REFERENCES `vendor` (`VendorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order`
--

LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,3,'2026-09-05',360000.00,'Net 30; freight included'),(2,8,'2026-09-15',14000.00,'Net 15');
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation`
--

DROP TABLE IF EXISTS `quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotation` (
  `QuotationNo` int(11) NOT NULL,
  `BranchID` int(11) NOT NULL,
  `QuotationDate` date NOT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `TotalAmount` decimal(12,2) NOT NULL,
  `AmountInWords` text DEFAULT NULL,
  `Status` varchar(50) DEFAULT 'Pending',
  PRIMARY KEY (`QuotationNo`),
  KEY `BranchID` (`BranchID`),
  CONSTRAINT `quotation_ibfk_1` FOREIGN KEY (`BranchID`) REFERENCES `client_branch` (`BranchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation`
--

LOCK TABLES `quotation` WRITE;
/*!40000 ALTER TABLE `quotation` DISABLE KEYS */;
INSERT INTO `quotation` VALUES (1,1,'2026-09-10','Office IT setup — 10 workstations',575000.00,'Five lakh seventy-five thousand taka only','Accepted'),(2,4,'2026-09-24','5 printers for branch office',60600.00,'Sixty thousand six hundred taka only','Pending');
/*!40000 ALTER TABLE `quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_item`
--

DROP TABLE IF EXISTS `quotation_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotation_item` (
  `QuotationItemID` int(11) NOT NULL,
  `QuotationNo` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `UnitPrice` decimal(12,2) NOT NULL,
  `TotalPrice` decimal(12,2) NOT NULL,
  `WarrantyMonths` int(11) DEFAULT NULL,
  PRIMARY KEY (`QuotationItemID`),
  KEY `QuotationNo` (`QuotationNo`),
  KEY `ProductID` (`ProductID`),
  CONSTRAINT `quotation_item_ibfk_1` FOREIGN KEY (`QuotationNo`) REFERENCES `quotation` (`QuotationNo`) ON DELETE CASCADE,
  CONSTRAINT `quotation_item_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_item`
--

LOCK TABLES `quotation_item` WRITE;
/*!40000 ALTER TABLE `quotation_item` DISABLE KEYS */;
INSERT INTO `quotation_item` VALUES (1,1,5,10,37500.00,375000.00,36),(2,1,12,10,15800.00,158000.00,36),(3,1,16,2,10500.00,21000.00,12),(4,1,28,2,10500.00,21000.00,12),(5,2,16,5,10500.00,52500.00,12),(6,2,19,3,2700.00,8100.00,24);
/*!40000 ALTER TABLE `quotation_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `RoleID` int(11) NOT NULL,
  `RoleName` varchar(50) NOT NULL,
  PRIMARY KEY (`RoleID`),
  UNIQUE KEY `RoleName` (`RoleName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin'),(4,'Buyer'),(3,'Inventory Staff'),(2,'Sales Manager');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `RoleID` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `PasswordHash` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`),
  KEY `RoleID` (`RoleID`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `roles` (`RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'admin','$2y$10$OqZWpkVTtjJzdRGEtXvp9edlbMB/PzmLonS5DFCeOcdClJ.IfVVKm','admin@sebabd.com','System Administrator','+880 1711 000 001','2026-09-24 22:21:38'),(2,2,'sales','$2y$10$eDaJsZ22IuJmK4p9pEGgw.4E/4ss51jW/P4M3UuFE/CP2y2InqJ6e','sales@sebabd.com','Farhana Akter','+880 1711 000 002','2026-09-24 22:21:38'),(3,3,'stock','$2y$10$nkvsZQaDu9k8vydlWzq1ZeTXAtNzHUWRGJb8gLC26BQ9g85e05N2e','stock@sebabd.com','Tanvir Hasan','+880 1711 000 003','2026-09-24 22:21:38'),(4,4,'buyer','$2y$10$zLMVgCGgoi2.bz4qbdg94uZzY0l/kAMq0w0ogfrB/rPl5Btfldmaq','buyer@sebabd.com','Rafi Karim','+880 1711 000 004','2026-09-24 22:21:38'),(5,4,'karim','$2y$10$7g5p7bvP0wK5Dx91BiHG..qXrIl5krKo/NEPSnTysXOcU14DZ2FqO','karim@test.local','Karim Uddin','01711223344','2026-09-24 22:52:07'),(6,4,'acme_procure','$2y$10$KM1h2ukhfU3rViXwfa14Q.x0v26ZOazbOmfYOVZlxb8YNhdWD2xZW','procure@acme.com.bd','Ms. Sultana','880 1811 223344','2026-09-24 22:52:07'),(7,4,'AshrafulAraf','$2y$10$XKyGEBMwjkx7D7QC929qYej5wvejZlNUuy9Tfnfy2iD3Amlyc7vi6','thegamerzdude@gmail.com','Sami Yusuf','01833877945','2026-09-24 23:12:12');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor` (
  `VendorID` int(11) NOT NULL,
  `VendorName` varchar(255) NOT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `ContactPhone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`VendorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` VALUES (1,'Dell Bangladesh Distribution','Dhaka','+880 1711 200 001'),(2,'HP Bangladesh Distribution','Dhaka','+880 1711 200 002'),(3,'Asus Bangladesh Distribution','Dhaka','+880 1711 200 003'),(4,'Lenovo Bangladesh Distribution','Dhaka','+880 1711 200 004'),(5,'Anviz International (USA)','USA','+1 949 261 8998'),(6,'Epson Singapore Pte. Ltd.','Singapore','+65 6586 0300'),(7,'Toshiba TEC Singapore','Singapore','+65 6270 3777'),(8,'Global IT Trading','Dhaka','+880 1711 200 008');
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-24 23:23:11
