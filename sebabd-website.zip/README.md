# SebaBD — Total IT System Solution (sebabd.com)

E-commerce storefront for **SebaBD** (sebabd.com), a Bangladeshi IT products
and services company. PHP + MySQL, backed by the **SEBABD schema (final
rev. 2)** — 17 tables covering users/roles, clients and their branches, catalog
(categories / vendors / products / serialized instances), orders, B2B
quotations, invoices, payment receipts and purchase orders.

The seed data mirrors the **real sebabd.com catalog**: 28 products across 11
categories (laptops, desktops, all-in-ones, monitors, printers, photocopiers,
projectors, UPS, mice, storage, access control) with actual BDT (৳) prices and
official product images.

## Requirements

- [XAMPP](https://www.apachefriends.org/) (PHP 8.1+ with `pdo_mysql`, MySQL/MariaDB)
  - Verified with XAMPP 8.2.12 / MariaDB 10.4.32

## Setup (XAMPP)

1. Start **MySQL** from the XAMPP Control Panel (Apache optional — only needed
   if you serve the site from `htdocs`).
2. Import the database:

   ```bash
   # from the project root
   C:\xampp\mysql\bin\mysql.exe -u root < database\sebabd.sql
   ```

   or open <http://localhost/phpmyadmin> → **Import** → choose
   `database/sebabd.sql`.

3. Check the credentials in `config.php` (defaults match a stock XAMPP:
   host `127.0.0.1`, user `root`, empty password, database `sebabd`).

4. Serve the site:

   ```bash
   # option A — PHP built-in server (quick)
   C:\xampp\php\php.exe -S 127.0.0.1:8787
   # then open http://127.0.0.1:8787/index.php

   # option B — copy the project into C:\xampp\htdocs\sebabd
   # then open http://localhost/sebabd/
   ```

> If the database is stopped or not imported yet, the storefront still renders
> from built-in demo data and shows a small "database offline" notice — no
> crash.

## Seeded logins

| Username | Password    | Role             |
|----------|-------------|------------------|
| `admin`  | `admin123`  | Admin            |
| `sales`  | `sales123`  | Sales Manager    |
| `stock`  | `stock123`  | Inventory Staff  |
| `buyer`  | `buyer123`  | Buyer (customer) |

Passwords are stored as real bcrypt hashes (`password_hash()`), so these work
with `password_verify()` once login pages exist.

## File structure

| File | Purpose |
|------|---------|
| `index.php` | Storefront homepage — categories & products rendered from the DB |
| `config.php` | DB credentials + site settings |
| `db.php` | PDO helper (`db()`, `db_fetch_all()`) with graceful fallback |
| `catalog-data.php` | Product images/badges/copy keyed by `ProductID`, category icons, BDT formatter, offline fallback |
| `database/sebabd.sql` | Schema (SEBABD rev. 2 DDL, verbatim) + real catalog seed data |
| `style.css` | Stylesheet (dark/green SebaBD theme) |
| `images/logo/cropped-cropped-u135.png` | Official SebaBD logo |

## How the schema maps to the site

- **CATEGORY** → "Shop by category" sidebar (query, not hard-coded)
- **PRODUCT + CATEGORY** → featured product grid; `StandardPrice` drives the
  ৳ price shown on each card (with strike-through when a deal price exists)
- **PRODUCT.IsSerialized / StockQty / PRODUCT_INSTANCE** → the stock line on
  each card: serialized products count `PRODUCT_INSTANCE` rows with
  `Status = 'In Stock'`; non-serialized products use `StockQty`
- **USERS / ROLES / CLIENT / CLIENT_BRANCH / ORDERS / QUOTATION / INVOICE /
  PAYMENT_RECEIPT / PURCHASE_ORDER** → seeded with realistic BDT demo data,
  ready for the login, checkout, quotation/invoice and back-office pages

Product **images, badges and marketing copy are not schema columns**, so they
live in `catalog-data.php` keyed by `ProductID` (pulled from the official
sebabd.com catalog). If you add products to the DB, add a matching entry there
(or the card renders with no image/blurb).

## Notes for the DBMS lab

- The DDL is imported **verbatim** — including the `INVOICE` XOR constraint
  (quotation **or** order, never both) and the snapshot-total policy.
- Demo data exercises both invoice sources: invoice #1 from the accepted
  quotation (B2B, branch-linked, part-paid ৳400,000 with balance remaining),
  invoice #2 from the online order (fully paid).
- Keep `TotalAmount`/`TotalPrice`/`RemainingBalance` maintained by application
  logic (or triggers) at write time, as the DDL header notes.
