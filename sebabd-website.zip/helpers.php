<?php
/**
 * SebaBD — shared helpers: session/auth, flash messages, DB insert helpers.
 */
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ------------------------------------------------------------------ auth */

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    static $user = null;
    static $loaded = false;
    if (!$loaded) {
        $rows = db_fetch_all(
            'SELECT u.UserID, u.Username, u.FullName, u.Email, r.RoleName
             FROM USERS u JOIN ROLES r ON r.RoleID = u.RoleID
             WHERE u.UserID = :id',
            [':id' => (int) $_SESSION['user_id']]
        );
        $user = $rows[0] ?? null;
        $loaded = true;
    }
    return $user;
}

function require_login(string $redirectBack = ''): array
{
    $user = current_user();
    if (!$user) {
        $back = $redirectBack !== '' ? $redirectBack : ($_SERVER['REQUEST_URI'] ?? 'index.php');
        header('Location: login.php?next=' . urlencode($back));
        exit;
    }
    return $user;
}

/* -------------------------------------------------------------- partials */

/**
 * Render a partial template with isolated variables and return its HTML.
 * $path is relative to the project root, e.g. 'partials/header.php'.
 */
function partial_render(string $path, array $vars = []): string
{
    extract($vars, EXTR_SKIP);
    ob_start();
    require __DIR__ . '/' . ltrim($path, '/');
    return (string) ob_get_clean();
}

/* -------------------------------------------------------------- flash */

function flash_set(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_take(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

function render_flashes(): string
{
    $out = '';
    foreach (flash_take() as $f) {
        $cls = $f['type'] === 'error' ? 'alert-danger' : 'alert-success';
        $out .= '<div class="alert ' . $cls . ' alert-dismissible fade show" role="alert">'
              . htmlspecialchars($f['message'])
              . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
              . '</div>';
    }
    return $out;
}

/* --------------------------------------------------------- old input */

function old(string $key, string $default = ''): string
{
    return htmlspecialchars($_SESSION['old'][$key] ?? $default, ENT_QUOTES);
}

function keep_old(array $data): void
{
    $_SESSION['old'] = $data;
}

function clear_old(): void
{
    unset($_SESSION['old']);
}

/* ---------------------------------------------------------- DB writes */

/**
 * Next free integer ID for a table (schema uses explicit INT primary keys).
 * Good enough for lab use; wrap the caller's inserts in a transaction.
 */
function next_id(PDO $pdo, string $table, string $column): int
{
    return (int) $pdo->query("SELECT COALESCE(MAX($column), 0) + 1 AS n FROM `$table`")
                     ->fetch()['n'];
}

/**
 * Escape a string literal for embedding in SQL (single quotes, backslashes,
 * and the utf8mb4-safe NUL handling). Only used where prepared statement
 * parameters can't be used (e.g. ON DUPLICATE constructions); values are
 * still escaped here.
 */
function sql_str(?string $value): string
{
    $pdo = db();
    if ($pdo) {
        return $pdo->quote((string) $value);
    }
    return "'" . addcslashes((string) $value, "'\\") . "'";
}

/* ------------------------------------------------------- amount words */

/**
 * Amount in words for financial documents (BDT). Two amounts per document
 * (QUOTATION/INVOICE snapshots) need this per the DDL.
 */
function amount_in_words(float $amount): string
{
    $amount = round($amount, 2);
    $taka   = (int) $amount;
    $poisha = (int) round(($amount - $taka) * 100);

    $ones = [
        '', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
        'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen',
        'seventeen', 'eighteen', 'nineteen',
    ];
    $tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

    $toWords = function (int $n) use ($ones, $tens, &$toWords): string {
        if ($n === 0) return '';
        if ($n < 20) return $ones[$n];
        if ($n < 100) return trim($tens[intdiv($n, 10)] . ' ' . $toWords($n % 10));
        return trim($ones[intdiv($n, 100)] . ' hundred ' . $toWords($n % 100));
    };

    $parts = [];
    $kotis = intdiv($taka, 10000000);   // 1 koti = 10 million
    $lakhs = intdiv($taka % 10000000, 100000);
    $thou  = intdiv($taka % 100000, 1000);
    $rest  = $taka % 1000;

    if ($kotis > 0) $parts[] = $toWords($kotis) . ' koti';
    if ($lakhs > 0) $parts[] = $toWords($lakhs) . ' lakh';
    if ($thou  > 0) $parts[] = $toWords($thou) . ' thousand';
    if ($rest  > 0) $parts[] = $toWords($rest);

    $words = $parts ? implode(' ', $parts) : 'zero';
    $words .= ' taka';
    if ($poisha > 0) {
        $words .= ' and ' . $toWords($poisha) . ' poisha';
    }
    return ucfirst($words . ' only');
}
